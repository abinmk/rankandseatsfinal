// frontend/src/data/demoAllotments.js
const demoAllotments = [
    {
      id: 1,
      name: 'College A',
      course: 'Course A',
      seats: 50,
      // other fields
    },
    {
      id: 2,
      name: 'College B',
      course: 'Course B',
      seats: 30,
      // other fields
    },
    // add more demo data
  ];
  
  export default demoAllotments;
  