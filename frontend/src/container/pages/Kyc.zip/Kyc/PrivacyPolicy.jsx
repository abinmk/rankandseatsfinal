import React from 'react';
import Header from './Header';

const PrivacyPolicy = () => {
  return (
    <>
      <Header />
      <div className="container py-5">
        <h1 className="mb-4 text-center">Privacy Policy</h1>
        <div className="content">
          <p>
            We respect your privacy and value the trust you have placed in Rank and Seats (“Rank and Seats” “Rank and Seats 
            App” “Rank and Seats” “RanknSeats” “Company” “Our” “Us” and “We”). We are fully committed to securing our customer 
            information and privacy by complying with this Privacy Policy.
          </p>
          {/* Add more content here from the document */}
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;
