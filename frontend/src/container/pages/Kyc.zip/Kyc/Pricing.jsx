import React from 'react';

const Pricing = () => {
  return (
    <div className="container">
      <h1>Pricing</h1>
      <p>Choose the best plan that suits your needs:</p>
      <ul>
        <li>Free Plan: Access basic features with limited data.</li>
        <li>Premium Plan: $29.99/month - Full access to all features and detailed analytics.</li>
        <li>Enterprise Plan: Contact us for a custom plan tailored to your organization.</li>
      </ul>
    </div>
  );
};

export default Pricing;
