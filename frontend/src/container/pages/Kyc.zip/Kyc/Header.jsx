import React from 'react';
import { Link } from 'react-router-dom';


const Header = () => {
  return (
    <header className="py-3 bg-dark text-white">
      <div className="container d-flex justify-content-between align-items-center">
        <Link to="/" className="navbar-brand">
          <img src="/static/logo.png" alt="Rank and Seats" height="50" />
        </Link>
        <nav>
          <ul className="list-unstyled d-flex mb-0">
            <li className="ms-3">
              <Link to="/" className="text-white">Home</Link>
            </li>
            <li className="ms-3">
              <Link to="/about-us" className="text-white">About Us</Link>
            </li>
            <li className="ms-3">
              <Link to="/contact-us" className="text-white">Contact Us</Link>
            </li>
            <li className="ms-3">
              <Link to="/pricing" className="text-white">Pricing</Link>
            </li>
            <li className="ms-3">
              <Link to="/features" className="text-white">Features</Link>
            </li>
            <li className="ms-3 dropdown">
                <a
                    href="#"
                    className="text-white dropdown-toggle"
                    id="infoDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    Info
                </a>
                <ul className="dropdown-menu dropdown-menu-dark" aria-labelledby="infoDropdown">
                    <li>
                    <Link to="/privacy-policy" className="dropdown-item">Privacy Policy</Link>
                    </li>
                    <li>
                    <Link to="/terms-and-conditions" className="dropdown-item">Terms & Conditions</Link>
                    </li>
                    <li>
                    <Link to="/cancellation-refund-policy" className="dropdown-item">Cancellation/Refund Policy</Link>
                    </li>
                </ul>
                </li>

          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
