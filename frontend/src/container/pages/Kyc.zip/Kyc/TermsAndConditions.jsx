import React from 'react';
import Header from './Header';

const TermsAndConditions = () => {
  return (
    <>
      <Header />
      <div className="container py-5">
        <h1 className="mb-4 text-center">Terms and Conditions</h1>
        <div className="content">
          <p>
            The Rank and Seats website (“Website”), mobile applications (Rank and Seats App and Rank and Seats App) 
            (“App”), and related services (together with the Website and App the “Service”) are operated by Rank 
            and Seats (“Company” “Rank and Seats” Rank and Seats School “us” or “we”). Access and use of the Service 
            are subject to the following Terms and Conditions of Service (“Terms and Conditions”). By accessing or 
            using any part of the Service you represent that you have read, understood, and agree to be bound by these 
            Terms and Conditions including any future modifications.
          </p>
          {/* Add more content here from the document */}
        </div>
      </div>
    </>
  );
};

export default TermsAndConditions;
