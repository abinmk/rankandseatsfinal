import React, { useState, useEffect, useCallback, useMemo } from 'react';
import axios from 'axios';
import _ from 'lodash';
import GenericTable from './GenericTable';
import { collegesColumns, collegesFiltersConfig } from './collegesConfig';
import './Colleges.scss';

const Colleges = () => {
  const [data, setData] = useState([]);
  const [filterOptions, setFilterOptions] = useState({});
  const [filters, setFilters] = useState({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(true);

  const apiUrl = import.meta.env.VITE_API_URL;

  const getFilterParamName = useMemo(() => {
    const filterMapping = {
      state: 'state',
      institute: 'collegeName',
      instituteType: 'instituteType',
      university: 'universityName',
      yearOfEstablishment: 'yearOfEstablishment',
      beds: 'totalHospitalBeds'
    };
    return (filterKey) => filterMapping[filterKey] || filterKey;
  }, []);

  const fetchData = useCallback(
    _.debounce(async (page, pageSize, filters) => {
      setLoading(true);
      try {
        const response = await axios.get(`${apiUrl}/colleges`, {
          params: {
            page,
            limit: pageSize,
            ...filters
          }
        });
        setData(response.data.data);
        setPage(response.data.currentPage);
        setTotalPages(response.data.totalPages);
      } catch (error) {
        console.error('Error fetching college data:', error);
      }
      setLoading(false);
    }, 500),
    [apiUrl]
  );

  const fetchFilterOptions = useCallback(async () => {
    setFilterLoading(true);
    try {
      const response = await axios.get(`${apiUrl}/colleges/filters`);
      setFilterOptions(response.data);
    } catch (error) {
      console.error('Error fetching filter options:', error);
    }
    setFilterLoading(false);
  }, [apiUrl]);

  useEffect(() => {
    fetchData(page, pageSize, buildFilterParams());
    return () => {
      fetchData.cancel();
    };
  }, [fetchData, filters, page, pageSize]);

  useEffect(() => {
    fetchFilterOptions();
  }, [fetchFilterOptions]);

  const buildFilterParams = () => {
    const params = {};
    Object.keys(filters).forEach((filterKey) => {
      const filterValue = filters[filterKey];
      if (typeof filterValue === 'object' && filterValue !== null) {
        params[`${getFilterParamName(filterKey)}Min`] = filterValue.min;
        params[`${getFilterParamName(filterKey)}Max`] = filterValue.max;
      } else {
        params[getFilterParamName(filterKey)] = filterValue;
      }
    });
    return params;
  };

  const countAppliedFilters = () => {
    let count = 0;
    for (const key in filters) {
      if (Array.isArray(filters[key])) {
        count += filters[key].length;
      } else if (filters[key] && typeof filters[key] === 'object') {
        if (filters[key].min !== undefined || filters[key].max !== undefined) {
          count += 1;
        }
      } else if (filters[key]) {
        count += 1;
      }
    }
    return count;
  };

  return (
    <div className="colleges-container">
      <GenericTable
        data={data}
        columns={collegesColumns}
        filtersConfig={collegesFiltersConfig}
        headerTitle="Colleges"
        filters={filters}
        setFilters={setFilters}
        page={page}
        setPage={setPage}
        totalPages={totalPages}
        setTotalPages={setTotalPages}
        filterOptions={filterOptions}
        loading={loading}
        filterLoading={filterLoading}
        fetchData={fetchData}
        pageSize={pageSize}
        setPageSize={setPageSize}
        getFilterParamName={getFilterParamName}
        appliedFiltersCount={countAppliedFilters()} // Pass applied filters count
      />
    </div>
  );
};

export default Colleges;
